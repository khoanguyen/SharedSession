﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebForm
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _sessionID.Text = Session.SessionID;
            _userData.Text = GetUserData();
        }

        private string GetUserData()
        {
            string key = "UserData";
            if (Session[key] == null) 
                Session[key] = "Here is the message form ASP.NET Webform";
            return Session[key] as String;
        }
    }
}

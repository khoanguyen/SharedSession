﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Configuration;

namespace WebForm
{
    public class Global : System.Web.HttpApplication
    {

        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup

        }

        void Application_End(object sender, EventArgs e)
        {
            //  Code that runs on application shutdown

        }

        void Application_Error(object sender, EventArgs e)
        {
            // Code that runs when an unhandled error occurs

        }

        void Session_Start(object sender, EventArgs e)
        {
            var session = HttpContext.Current.Session;
            var request = HttpContext.Current.Request;
            var cookie = request.Cookies["ASP.NET_SessionId"];
            if (cookie != null && session != null && session.SessionID != null)
            {
                cookie.Value = session.SessionID;
                cookie.Domain = ConfigurationManager.AppSettings["TopLevelDomain"];

                // the full stop prefix denotes all sub domains
                cookie.Path = "/"; // default session cookie path root
            }
        }

        void Session_End(object sender, EventArgs e)
        {
            // Code that runs when a session ends. 
            // Note: The Session_End event is raised only when the sessionstate mode
            // is set to InProc in the Web.config file. If session mode is set to StateServer 
            // or SQLServer, the event is not raised.

        }

    }
}

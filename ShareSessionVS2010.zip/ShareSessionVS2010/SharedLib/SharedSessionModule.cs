﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedLib
{
    using System.Configuration;
    using System.Reflection;
    using System.Web;

    /// <summary>class used for sharing the session between app domains</summary>
    public class SharedSessionModule : IHttpModule
    {
        #region IHttpModule Members
        /// <summary>
        /// Initializes a module and prepares it to handle requests.
        /// </summary>
        /// <param name="context">An <see cref="T:System.Web.HttpApplication"/>
        /// that provides access to the methods,
        /// properties, and events common to all application objects within an ASP.NET
        /// application</param>
        /// <created date="5/31/2008" by="Peter Femiani"/>
        public void Init(HttpApplication context)
        {
            // Get the app name from config file...
            string appName = ConfigurationManager.AppSettings["ApplicationName"];
            if (!string.IsNullOrEmpty(appName))
            {
                FieldInfo runtimeInfo = typeof(HttpRuntime).GetField("_theRuntime", BindingFlags.Static | BindingFlags.NonPublic);
                HttpRuntime theRuntime = (HttpRuntime)runtimeInfo.GetValue(null);
                FieldInfo appNameInfo = typeof(HttpRuntime).GetField("_appDomainAppId", BindingFlags.Instance | BindingFlags.NonPublic);
                appNameInfo.SetValue(theRuntime, appName);
            }
        }

        /// <summary>
        /// Disposes of the resources (other than memory) used by the module that
        /// implements <see cref="T:System.Web.IHttpModule"/>.
        /// </summary>
        /// <created date="5/31/2008" by="Peter Femiani"/>
        public void Dispose()
        {
        }
        #endregion
    }
}

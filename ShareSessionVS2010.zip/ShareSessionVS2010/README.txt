---------------------------------------------------
System requirement

1. SQL Server 2008/2012 Express edition is enough

2. IIS Express or IIS 7 (IIS Express usually comes with VS2010 or you can get it with WebPI)

3. Certainly, Visual Studio 2010

---------------------------------------------------
Setting up

1. Creating State database. Open Start -> All Programs -> Microsoft Visual Studio 2010 -> Visual Studio Tools -> Visual Studio Command Prompt.
   Execute the following command:

	aspnet_regsql -ssadd -S <SQL server name> -E

2. Add to System32\drivers\etc\hosts file the following lines:

	127.0.0.1	ssasp.web.local
	127.0.0.1	ssmvc.web.local
   
3. Setup IIS Express. These project is set up for running on IIS Express, you can also set them up to run on IIS7. If you plan to set them up on IIS 7 then skip this step.
   Add the following contents to the <configuration><system.applicationHost><sites> section of C:\Users\<User name>\Documents\IISExpress\config\applicationhost.config
   
	<configuration>
		...
		<system.applicationHost>
			...
			<sites>
				...
				<site name="WebForm" id="<give it an unique id number>">
					<application path="/" applicationPool="Clr4IntegratedAppPool">
						<virtualDirectory path="/" physicalPath="<path to WebForm project folder>" />
					</application>
					<bindings>
						<binding protocol="http" bindingInformation="*:2026:ssasp.web.local" />
					</bindings>
				</site>
				<site name="MvcApp" id="<give it an unique id number>">
					<application path="/" applicationPool="Clr4IntegratedAppPool">
						<virtualDirectory path="/" physicalPath="<path to MvcApp project folder>" />
					</application>
					<bindings>
						<binding protocol="http" bindingInformation="*:2026:ssmvc.web.local" />
					</bindings>
				</site>
				...
			</sites>
		</system.applicationHost>
	</configuration>

   ENSURE that you set the id of the site with unique id for each site 
	E.g: 4 for WebForm and 5 for MvcApp

   ENSURE the physicalPath of each site point to the correct folder 
	E.g: c:\Projects\ShareSessionVS2010\WebForm and c:\Projects\ShareSessionVS2010\MvcApp)
	
4. Change sqlConnectionString of <sessionState> config in web.config files of both WebForm and MvcApp projects to your local SQL server
   No need to specify the database name since default database is ASPState

---------------------------------------------------
Open and Run

	You may be asked for Create Virtual Directory when opening the solution, just "Yes" to them all.
	
	Just press F5 to start debugging, I configured multiple start-up projects. 
	
	See SessionId and UserData shared between them.

---------------------------------------------------
What to be noticed

1. Global.asax.cs -> Session_Start method

2. SharedLib -> SharedSessionModule

3. SessionState config in web.config

4. AppSettings:
	<add key="TopLevelDomain" value="web.local" />
    <add key="ApplicationName" value="SharedSession"/>

The user data is set by WebForm. If it shows nothing on MvcApp, just refresh MvcApp.

Setting them running on IIS 7 is easier, you just need change application Url in Web section of projects's Properties and ensure that IIS 7 allows debugging.
	
---------------------------------------------------